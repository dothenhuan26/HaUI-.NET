﻿namespace Bai8_Nhuan381_P2
{
    internal class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace De7_Nhuan_381
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Medicine> medicines = new List<Medicine>();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (validate() == true)
            {
                Medicine medicine = new Medicine();
                medicine.Name = inputName.Text.Trim();
                medicine.Type = inputType.IsChecked == true ? "Thuốc kê đơn" : "";
                medicine.Amount = int.Parse(inputAmount.Text.Trim());
                medicine.Price = double.Parse(inputPrice.Text.Trim());
                medicines.Add(medicine);

                renderData.ItemsSource = null;
                renderData.ItemsSource = medicines;
                clearInput();

            }
        }

        private void clearInput()
        {
            inputName.Text = "";
            inputType.IsChecked = false;
            inputAmount.Text = "";
            inputPrice.Text = "";
        }

        private bool validate()
        {
            if (inputName.Text.Trim().Length == 0)
            {
                MessageBox.Show("Tên thuốc không được để trống!", "INVALID DATA", MessageBoxButton.OK, MessageBoxImage.Error);
                inputName.Focus();
                return false;
            }
            else
            {
                var findM = medicines.FirstOrDefault(x => x.Name.Equals(inputName.Text.Trim()));
                if (findM != null)
                {
                    MessageBox.Show("Tên thuốc đã tồn tại!", "INVALID DATA", MessageBoxButton.OK, MessageBoxImage.Error);
                    inputName.Text = "";
                    inputName.Focus();
                    return false;
                }
            }

            if (inputAmount.Text.Trim().Length == 0)
            {
                MessageBox.Show("Số lượng mua không được để trống!", "INVALID DATA", MessageBoxButton.OK, MessageBoxImage.Error);
                inputAmount.Focus();
                return false;
            }
            else
            {
                int amount;
                bool flag1;
                flag1 = int.TryParse(inputAmount.Text.Trim(), out amount);
                if (!flag1)
                {
                    MessageBox.Show("Số lượng mua phải là số nguyên lớn hơn 0!", "INVALID DATA", MessageBoxButton.OK, MessageBoxImage.Error);
                    inputPrice.Text = "";
                    inputPrice.Focus();
                    return false;
                }
                else if (amount <= 0)
                {
                    MessageBox.Show("Số lượng mua phải là số nguyên lớn hơn 0!", "INVALID DATA", MessageBoxButton.OK, MessageBoxImage.Error);
                    inputPrice.Text = "";
                    inputPrice.Focus();
                    return false;
                }
            }

            if (inputPrice.Text.Trim().Length == 0)
            {
                MessageBox.Show("Đơn giá không được để trống!", "INVALID DATA", MessageBoxButton.OK, MessageBoxImage.Error);
                inputAmount.Focus();
                return false;
            }
            else
            {
                double price;
                bool flag;
                flag = double.TryParse(inputPrice.Text.Trim(), out price);
                if (!flag)
                {
                    MessageBox.Show("Đơn giá phải là số thực!", "INVALID DATA", MessageBoxButton.OK, MessageBoxImage.Error);
                    inputPrice.Text = "";
                    inputPrice.Focus();
                    return false;
                }
                else if (price <= 0)
                {
                    MessageBox.Show("Đơn giá phải là số thực lớn hơn 0!", "INVALID DATA", MessageBoxButton.OK, MessageBoxImage.Error);
                    inputPrice.Text = "";
                    inputPrice.Focus();
                    return false;
                }
            }
            return true;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            List<Medicine> list = new List<Medicine>();
            if (medicines.Count == 0)
            {
                MessageBox.Show("Không có dữ liệu!", "INVALID DATA", MessageBoxButton.OK, MessageBoxImage.Error);
                inputPrice.Text = "";
                inputPrice.Focus();
                return;
            };
            var min = medicines.Min(m => m.Amount);
            list = medicines.Where(m => m.Amount == min).ToList();
            Window2 window2 = new Window2();
            window2.render2.ItemsSource = list;
            window2.Show();
        }
    }
}

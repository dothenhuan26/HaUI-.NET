﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace De7_Nhuan_381
{
    internal class Medicine
    {
        private string _name;
        private string _type;
        private int _amount;
        private double _price;

        public double Total
        {
            get
            {
                return this._amount * this._price;
            }
        }
        public double Price
        {
            get { return _price; }
            set { _price = value; }
        }

        public string Type
        {
            get { return _type; }
            set { _type = value; }
        }


        public int Amount
        {
            get { return _amount; }
            set { _amount = value; }
        }


        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

    }
}
